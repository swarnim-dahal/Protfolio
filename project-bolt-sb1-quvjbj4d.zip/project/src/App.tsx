import React, { useEffect } from 'react';
import { Github, Linkedin, Mail, ChevronDown, ExternalLink } from 'lucide-react';

function App() {
  useEffect(() => {
    // Update title
    document.title = "Swarnim Dahal | Portfolio";
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="bg-gray-900 text-gray-100 min-h-screen">
      {/* Navbar */}
      <nav className="fixed w-full bg-gray-900/95 backdrop-blur-sm z-50 border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-8">
              <a href="#" className="text-xl font-bold">SD</a>
              <div className="hidden md:flex space-x-6">
                <button onClick={() => scrollToSection('about')} className="hover:text-blue-400 transition-colors">About</button>
                <button onClick={() => scrollToSection('projects')} className="hover:text-blue-400 transition-colors">Projects</button>
                <button onClick={() => scrollToSection('skills')} className="hover:text-blue-400 transition-colors">Skills</button>
                <button onClick={() => scrollToSection('contact')} className="hover:text-blue-400 transition-colors">Contact</button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative">
        <div className="text-center space-y-6 px-4">
          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
            Swarnim Dahal
          </h1>
          <p className="text-xl md:text-2xl text-gray-400 max-w-2xl mx-auto">
            Passionate Developer & Technology Enthusiast
          </p>
          <button
            onClick={() => scrollToSection('about')}
            className="animate-bounce mt-8 inline-block"
          >
            <ChevronDown size={32} className="text-gray-400" />
          </button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-8">About Me</h2>
          <div className="space-y-4 text-gray-300">
            <p>
              I am passionate about technology and development, constantly exploring new ways to innovate and create. My journey in programming has equipped me with strong foundations in C, C++, and Python, and I'm currently expanding my skillset by learning JavaScript and CSS.
            </p>
            <p>
              Beyond my technical pursuits, I've taken on various leadership roles that have shaped my collaborative and organizational skills. I've worked as an event organizer for TechTrix's Minds In Motion program, where I helped coordinate and execute successful tech events.
            </p>
            <p>
              I'm also proud to have served as a general member in several prestigious organizations:
            </p>
            <ul className="list-disc list-inside ml-4 space-y-2">
              <li>LEO Club of Kathmandu Natural</li>
              <li>Rotaract Club of Patan</li>
              <li>CSIT Association of Nepal</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-gray-800/50 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold mb-12">Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: "Smart Appliance",
                description: "A smart device control system for automated home management.",
                github: "swarnim-dahal/Smartappliance"
              },
              {
                title: "Project K",
                description: "A personal multi-feature project combining various technologies.",
                github: "swarnim-dahal/ProjectK"
              },
              {
                title: "Traffic Management System",
                description: "An innovative approach to traffic light automation and control.",
                github: "swarnim-dahal/Traffic-Management"
              },
              {
                title: "Volume & Brightness Controller",
                description: "Intuitive gesture-based control for system volume and brightness.",
                github: "swarnim-dahal/Voume-Brightness"
              },
              {
                title: "Gesture Controlled System",
                description: "Advanced interface for device control through gesture recognition.",
                github: "swarnim-dahal/GestureControlled"
              }
            ].map((project, index) => (
              <div
                key={index}
                className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors group"
              >
                <h3 className="text-xl font-semibold mb-3 group-hover:text-blue-400 transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-400 mb-4">{project.description}</p>
                <a
                  href={`https://github.com/${project.github}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors"
                >
                  <Github className="w-4 h-4 mr-2" />
                  View on GitHub
                  <ExternalLink className="w-4 h-4 ml-1" />
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-12">Skills</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {[
              { name: "C", level: "Advanced" },
              { name: "C++", level: "Advanced" },
              { name: "Python", level: "Advanced" },
              { name: "JavaScript", level: "Learning" },
              { name: "CSS", level: "Learning" }
            ].map((skill, index) => (
              <div
                key={index}
                className="bg-gray-800 p-6 rounded-lg text-center hover:bg-gray-700 transition-all transform hover:-translate-y-1"
              >
                <h3 className="text-xl font-semibold mb-2">{skill.name}</h3>
                <p className="text-gray-400 text-sm">{skill.level}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-800/50 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-12">Contact</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-xl font-semibold mb-6">Get in touch</h3>
              <div className="space-y-4">
                <a
                  href="mailto:your.email@example.com"
                  className="flex items-center text-gray-300 hover:text-blue-400 transition-colors"
                >
                  <Mail className="w-5 h-5 mr-3" />
                  Email Me
                </a>
                <a
                  href="https://github.com/swarnim-dahal"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-gray-300 hover:text-blue-400 transition-colors"
                >
                  <Github className="w-5 h-5 mr-3" />
                  GitHub
                </a>
                <a
                  href="https://linkedin.com/in/swarnim-dahal"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-gray-300 hover:text-blue-400 transition-colors"
                >
                  <Linkedin className="w-5 h-5 mr-3" />
                  LinkedIn
                </a>
              </div>
            </div>
            <form className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-1">
                  Message
                </label>
                <textarea
                  id="message"
                  rows={4}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg transition-colors"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-8 text-center text-gray-400">
        <p>© 2024 Swarnim Dahal. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;